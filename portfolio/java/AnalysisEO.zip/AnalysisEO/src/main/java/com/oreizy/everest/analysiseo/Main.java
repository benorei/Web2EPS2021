/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oreizy.everest.analysiseo;

/**
 *
 * @author eoreizy
 * For some reason javafx breaks if we don't make a new main class. idk why but oh well.
 */
public class Main {
    public static void main(String[] args){
        App.main(args);
    }
}

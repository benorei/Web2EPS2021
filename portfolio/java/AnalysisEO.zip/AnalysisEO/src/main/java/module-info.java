module com.oreizy.everest.analysiseo {
    requires javafx.controls;
    exports com.oreizy.everest.analysiseo;
}
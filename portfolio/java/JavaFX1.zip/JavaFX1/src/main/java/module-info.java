module com.mycompany.javafx1 {
    requires javafx.controls;
    exports com.mycompany.javafx1;
}